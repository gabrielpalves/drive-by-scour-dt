# Bundle: s11_bear  —  + bearing (HEAD)

Self-contained: MATLAB generator + Python ablation, both PRESET for this
stage. Extract into the repo root on the Lab PC. No editing needed.

## 0. AUDIT 2026-07-17 — read first
- Extract into a FRESH working copy; do NOT extract over an old run. A00
  writes a gen_schema and ABORTS if you resume a folder from other code.
- One-time sanity (MATLAB): `smoke_audit`, `smoke_stage3`, `smoke_geometry`;
  (Python): `python check_split_grouping.py`, `python check_loader_provenance.py`,
  `python check_cache_provenance.py`, `python check_protocol_hash.py`.
  All must print ALL PASS.
- Run STAGE s0_scour FIRST: it selects the architecture and writes
  results/_champion_arch_<schema>_ph-<hash>.json; every later rung reads it
  and errors if it is missing (no hardcoded champion anymore). On a DIFFERENT
  PC, copy that JSON here (or set CHAMPION_MANIFEST / CHAMPION_ARCH_OVERRIDE).
- PROTOCOL HASH (2026-07-19): every study/summary/manifest name carries a
  SHA-256 of the full protocol (dataset fingerprint, split, seeds, trials,
  pruner, search space, noise, targets). If ANY of those change, names
  change and old studies are orphaned — never resumed. The exact hashed
  descriptor is written to the summary dir as protocol_descriptor.json.
- Study/DB/cache dirs are STAGE-prefixed, so rungs never cross-contaminate.

## 1. MATLAB — generate the data (noise-free, RAW format)
Open `scour_MATLAB/A00_Run.m` and RUN it. `STAGE` is already `s11_bear` and
`use_signal_noise = false` — measurement noise is added later, at LOAD time.
D01 saves the RAW, un-interpolated TIME-domain signal plus the space/crop
parameters; Python rebuilds the space window at load time (Option B), so the
noise model can change forever without regenerating.
Output -> `scour_MATLAB/Results/<stage>_L<len>_st<N>/`; move it under `data/`.
Folder names are SHORT now (Windows MAX_PATH); the full descriptor lives in
`case_info.case_desc` / `case_info.txt`.

## 2. (once) verify the MATLAB<->Python transform
After the FIRST state exists, in MATLAB:  `smoke_raw_parity('Results/<case>')`
then:  `python check_raw_parity.py "scour_MATLAB/Results/<case>"`
Must print PARITY PASS (max|MATLAB-Python| < 1e-12) before the long run.

## 3. Python — ablate
`python comprehensive_ablation_multidamage.py` (STAGE + SENSOR_NOISE preset).
Noise: `all_mult` = uniform 5% multiplicative on EVERY channel, injected at load
time onto the noise-free data. 100 trials x 3 seeds + the mixed pair [1,3];
summary -> `results/s11_bear_summary_ph-<hash>/` (+ leaderboards +
`protocol_descriptor.json`).

## Heads vs nuisances
HEADS = scour (per pier) + bearing (per abutment) ONLY. Crack, rail profile,
track-layer and wheel damage are NUISANCES: randomized, logged, never
estimated — the network must be INVARIANT to them.

## Requirements
torch, optuna, scikit-learn, numpy, scipy, joblib, matplotlib, seaborn,
PyWavelets, tqdm. Everything is resumable.
